PROTOTIPO GRATUITO - CONTROL DE GASTOS

Abre index.html en Chrome/Edge para probar la interfaz.
Incluye Dashboard, empleados, tarjetas por empleado, gastos, cuentas, centros, límites y autorizaciones.

NOTA: esta es una primera maqueta funcional local. Los datos se guardan en el navegador.
Para una versión real multiusuario agregaremos base de datos, usuarios/contraseñas, almacenamiento de comprobantes y envío de correos.
